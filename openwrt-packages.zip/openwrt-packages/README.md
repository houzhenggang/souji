﻿
从这里 https://gitlab.labs.nic.cz/jvcelak/openwrt-packages/tree/tvheadend 下载的





