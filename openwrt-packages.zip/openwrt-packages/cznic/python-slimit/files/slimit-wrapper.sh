#!/bin/sh
python -c "from slimit.minifier import main; main()" $@
